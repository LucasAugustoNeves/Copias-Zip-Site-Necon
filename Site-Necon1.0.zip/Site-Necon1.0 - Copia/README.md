<h1 align="center">
 	<br>
 	  <img width="200" src="https://github.com/LucasAugustoNeves/Site-Necon1.0/blob/main/_img/NEconLogo1.png" alt="awesome">
 	<br>
</h1>

# Site NEcon Contabilidade
> Projeto do novo site da necon contabilidade com interação do sistema NAwin

Esse é o novo site da Necon Contabilidade está sendo construido em um formato moderno e totalmente responsivo para se adquar a qualquer tela que o acesse.

testando github

## Histórico de lançamentos


* 0.0.1
    * Trabalho em andamento
* 1.1.0
    *  Site No Ar


## Meta

Lucas Augusto Neves –  lucasagneves@gmail.com.com

Distribuído sob a licença MIT. Veja `LICENSE` para mais informações.


