<?php

$condominio = $_POST["Condominiodata"];
$tipo = $_POST["tipodata"];
$nome = $_POST["nomedata"];
$historico = $_POST["historicodata"];
$anexo = $_POST["anexodata"];
$conteudo = "$condominio; $tipo; $nome; $historico; $anexo;";

$DATA=date("d/m/Y"); 
$HORA=time("H");

$arq=fopen("../../_ArquivosTXT/Ocorrencias.txt","a") or die("Erro na crição do arquivo EMPENHOS.TXT");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($condominio,100));

fwrite($arq,";");
fwrite($arq,str_pad($tipo,30));

fwrite($arq,";");
fwrite($arq,str_pad($nome,50));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,"-");
fwrite($arq,str_pad($historico,398));

fwrite($arq,"\r\n");
fwrite($arq,"+");
fwrite($arq,"-");
fwrite($arq,str_pad($anexo,398));

fwrite($arq,";");
fwrite($arq,"\r\n");

fclose($arq);

$arq=fopen("../../_ArquivosTXT/Ocorrencias.csv","a") or die("Erro na crição do arquivo EMPENHOS.CSV");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($condominio,100));

fwrite($arq,";");
fwrite($arq,str_pad($tipo,30));

fwrite($arq,";");
fwrite($arq,str_pad($nome,50));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,"-");
fwrite($arq,str_pad($historico,398));

fwrite($arq,"\r\n");
fwrite($arq,"+");
fwrite($arq,"-");
fwrite($arq,str_pad($anexo,398));

fwrite($arq,";");
fwrite($arq,"\r\n");

fclose($arq);

  echo "<meta http-equiv='refresh' content='3;URL=ocorrencias.html'>";

?>

<!DOCTYPE html>
<html lang="pt-BR" >
<head>
  <meta charset="UTF-8">
  <title>NEcon Gravar</title>
  <style>
    body {
  font-family: system-ui;
  background: #f01606;
  color: white;
  text-align: center;
}
  </style>

</head>
<body>
<!-- partial:index.partial.html -->
<h1>✔️ Gravado Com Sucesso</h1>
    <br>
    <br>
    <br>
<h2>A NEcon Contabilidade Agradece Sua Colaboração</h2>    
<!-- partial -->
  <script>
    document.getElementsByTagName("h1")[0].style.fontSize = "6vw";
  </script>
</body>
</html>