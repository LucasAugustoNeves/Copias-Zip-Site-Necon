<?php
$condominio = $_POST["Condominiodata"];
$fornecedor = $_POST["fornrcedordata"];
$tipo = $_POST["tipodata"];
$historico = $_POST["historicodata"];
$valor = $_POST["valordata"];
$ntonf = $_POST["recibodata"];
$nroos = $_POST["osdata"];
$destino = $_POST["destinodata"];


$conteudo = "* $condominio; $fornecedor; $tipo; $historico; $valor; $recibo; $os; $destino; ";


$DATA=date("d/m/Y"); 
$HORA=time("H");

$arq=fopen("../../_ArquivosTXT/Empenhos.txt","a") or die("Erro na crição do arquivo EMPENHOS.TXT");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($condominio,100));

fwrite($arq,";");
fwrite($arq,str_pad( $fornecedor,74));

fwrite($arq,";");
fwrite($arq,str_pad($tipo,50));

fwrite($arq,";");
fwrite($arq,str_pad($valor,20));

fwrite($arq,";");
fwrite($arq,str_pad($ntonf ,20));

fwrite($arq,";");
fwrite($arq,str_pad( $destino,20));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));

fwrite($arq,";");
fwrite($arq,str_pad($nroos,10));

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,"-");
fwrite($arq,str_pad($historico,100));

fwrite($arq,";");
fwrite($arq,"\r\n");

fclose($arq);

$arq=fopen("../../_ArquivosTXT/Empenhos.csv","a") or die("Erro na crição do arquivo EMPENHOS.CSV");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($condominio,100));

fwrite($arq,";");
fwrite($arq,str_pad( $fornecedor,74));

fwrite($arq,";");
fwrite($arq,str_pad($historico,50));

fwrite($arq,";");
fwrite($arq,str_pad($valor,20));

fwrite($arq,";");
fwrite($arq,str_pad($destino,20));

fwrite($arq,";");
fwrite($arq,str_pad( $nroos,20));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));

fwrite($arq,";");
fwrite($arq,str_pad($nroos,10));

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,"-");
fwrite($arq,str_pad($historico,100));

fwrite($arq,";");
fwrite($arq,"\r\n");

fclose($arq);

  echo "<meta http-equiv='refresh' content='3;URL=empenho.html'>";

?>

<!DOCTYPE html>
<html lang="pt-BR" >
<head>
  <meta charset="UTF-8">
  <title>NEcon Gravar</title>
  <style>
    body {
  font-family: system-ui;
  background: #f01606;
  color: white;
  text-align: center;
}
  </style>

</head>
<body>
<!-- partial:index.partial.html -->
<h1>✔️ Gravado Com Sucesso</h1>
    <br>
    <br>
    <br>
<h2>A NEcon Contabilidade Agradece Sua Colaboração</h2>    
<!-- partial -->
  <script>
    document.getElementsByTagName("h1")[0].style.fontSize = "6vw";
  </script>
</body>
</html>