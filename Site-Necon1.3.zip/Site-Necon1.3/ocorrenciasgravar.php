﻿<?php 



class GoogleRecaptcha
{
    /* Google recaptcha API url */
    private $google_url = "https://www.google.com/recaptcha/api/siteverify";
    private $secret = '6LfHp5cUAAAAAJLa0ZUCXVSkuhROPPUkw9W7hoB5';

    public function VerifyCaptcha($response)
    {
        $url = $this->google_url."?secret=".$this->secret.
            "&response=".$response;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        $curlData = curl_exec($curl);

        curl_close($curl);

        $res = json_decode($curlData, TRUE);
        if($res['success'] == 'true')
            return TRUE;
        else
            return FALSE;
    }

}

$message = 'Google reCaptcha';

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $response = $_POST['g-recaptcha-response'];

    if(!empty($response))
    {
        $cap = new GoogleRecaptcha();
        $verified = $cap->VerifyCaptcha($response);

        if($verified) {
            $message = "Captcha Success!";
            
header('Content-Type: text/html; charset=utf-8');    
       
echo "A NEcon AGRADECE PELAS SUAS INFORMAÇÕES, ESTAMOS GRAVANDO OS DADOS !";

$DATA=date("d/m/Y"); 
$HORA=time("H");

$arq=fopen("Ocorrencias.txt","a") or die("Erro na crição do arquivo OCORRENCIAS.TXT");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($CONDOMINIO,100));

fwrite($arq,";");
fwrite($arq,str_pad($TIPO,30));

fwrite($arq,";");
fwrite($arq,str_pad($NOME,50));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));
fwrite($arq,";");

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,str_pad($DESCRICAO,398));
fwrite($arq,";");

fwrite($arq,"\r\n");
fwrite($arq,"+");
fwrite($arq,str_pad($ANEXO,398));
fwrite($arq,";");

fwrite($arq,"\r\n");

fclose($arq);

$arq=fopen("Ocorrencias.csv","a") or die("Erro na crição do arquivo OCORRENCIAS.CSV");

fwrite($arq,"\r\n");

fwrite($arq,"*");
fwrite($arq,str_pad($CONDOMINIO,100));

fwrite($arq,";");
fwrite($arq,str_pad($TIPO,30));

fwrite($arq,";");
fwrite($arq,str_pad($NOME,50));

fwrite($arq,";");
fwrite($arq,str_pad($DATA,20));

fwrite($arq,";");
fwrite($arq,str_pad($HORA,20));
fwrite($arq,";");

fwrite($arq,"\r\n");
fwrite($arq,"#");
fwrite($arq,str_pad($DESCRICAO,398));
fwrite($arq,";");

fwrite($arq,"\r\n");
fwrite($arq,"+");
fwrite($arq,str_pad($ANEXO,398));
fwrite($arq,";");

fwrite($arq,"\r\n");

fclose($arq);

echo "<meta http-equiv='refresh' content='1;URL=ocorrencias.php'>";
        } else {
            $message = "Please reenter captcha";
            echo "<h1>erro</h1>";
        }
    }else{
        echo "captcha não prenchido";
        echo "<meta http-equiv='refresh' content='1;URL=ocorrencias.php'>";
    }
}










